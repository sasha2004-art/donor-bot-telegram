import html

class Text:
    @staticmethod
    def escape_html(text: str) -> str:
        """Экранирует специальные символы для parse_mode=HTML."""
        if not isinstance(text, str):
            text = str(text)
        return html.escape(text)

    @staticmethod
    def format_location_link(text: str, latitude: float | None, longitude: float | None) -> str:
        # Экранируем видимую часть текста для HTML
        safe_visible_text = Text.escape_html(text)
        
        if latitude and longitude:
            # Возвращаем HTML-ссылку
            url = f"https://yandex.ru/maps/?pt={longitude},{latitude}&z=18&l=map"
            return f'<a href="{url}">{safe_visible_text}</a>'
            
        # Если координат нет, возвращаем просто экранированный текст
        return safe_visible_text

    DONATION_TYPE_RU = {
        'whole_blood': 'Цельная кровь',
        'plasma': 'Плазма',
        'platelets': 'Тромбоциты',
        'erythrocytes': 'Эритроциты'
    }
    WELCOME = "👋 Добро пожаловать в бот донорского движения МИФИ!\n\nДля начала работы, пожалуйста, поделитесь своим контактом. Это необходимо для вашей идентификации в системе доноров."
    AUTH_SUCCESS = "✅ Авторизация прошла успешно! С возвращением, {name}!"
    START_REGISTRATION = "🔍 Похоже, вы у нас впервые. Давайте познакомимся!"
    GET_FULL_NAME = "📝 Введите, пожалуйста, ваше ФИО (например, Иванов Иван Иванович):"
    GET_UNIVERSITY = "🎓 Выберите ваш ВУЗ:"
    GET_CUSTOM_UNIVERSITY = "Введите полное название вашего ВУЗа:"
    GET_FACULTY = "🏛️ Выберите ваш факультет:"
    GET_CUSTOM_FACULTY = "Введите название вашего факультета:"
    GET_GROUP = "🔢 Введите номер вашей учебной группы (например, Б20-505):"
    GET_BLOOD_TYPE = "🩸 Укажите вашу группу крови:"
    GET_RH_FACTOR = "➕ Укажите ваш резус-фактор:"
    GET_GENDER = "🚻 Укажите ваш пол:"
    REGISTRATION_COMPLETE = "🎉 Отлично! Регистрация завершена. Теперь вы можете пользоваться всеми возможностями бота."
    ERROR_WRONG_FORMAT = "❌ Неверный формат. Пожалуйста, попробуйте еще раз."
    INFO_PREPARE = (
        "<b>Как подготовиться к сдаче крови:</b>\n\n"
        "<b>Накануне и в день сдачи крови запрещено:</b>\n"
        "▪️ Употреблять жирную, жареную, острую и копченую пищу, колбасные изделия, а также мясные, рыбные и молочные продукты, яйца и масло (в т.ч. растительное), шоколад, орехи и финики.\n"
        "▪️ Принимать алкоголь за 48 часов до донации.\n"
        "▪️ Принимать лекарства, содержащие аспирин и анальгетики, за 72 часа до донации.\n\n"
        "<b>Что нужно делать:</b>\n"
        "▪️ Хорошо выспаться.\n"
        "▪️ Легко позавтракать (сладкий чай, сухое печенье, каша на воде).\n"
        "▪️ Не курить за час до донации.\n"
        "▪️ Не приходить на донацию при недомогании."
    )
    INFO_CONTRAINDICATIONS = (
        "<b>Абсолютные противопоказания (отвод от донорства навсегда):</b>\n\n"
        "▪️ ВИЧ-инфекция, сифилис, вирусные гепатиты.\n"
        "▪️ Туберкулез (все формы).\n"
        "▪️ Болезни крови.\n"
        "▪️ Онкологические заболевания.\n"
        "▪️ Наркомания, алкоголизм.\n\n"
        "<b>Временные противопоказания:</b>\n"
        "▪️ Удаление зуба (10 дней).\n"
        "▪️ Нанесение татуировки, пирсинг (1 год).\n"
        "▪️ Ангина, грипп, ОРВИ (1 месяц после выздоровления).\n"
        "▪️ Прививки (от 10 дней до 1 года)."
    )
    INFO_AFTER = (
        "<b>Что делать после донации:</b>\n\n"
        "▪️ Отдохните 10–15 минут.\n"
        "▪️ Не снимайте повязку 3–4 часа.\n"
        "▪️ Не подвергайтесь физическим нагрузкам в течение дня.\n"
        "▪️ Воздержитесь от употребления алкоголя в течение суток.\n"
        "▪️ Пейте больше жидкости и полноценно питайтесь в течение двух суток."
    )
    INFO_CONTACTS = (
        "<b>Связаться с организаторами:</b>\n\n"
        "Если у вас возникли вопросы, вы можете связаться с нами:\n"
        "▪️ Телеграм-чат для доноров: [ссылка на чат]\n"
        "▪️ Ответственный за донорское движение: [Александр, @Alkzaz7]"
    )
    NEW_EVENT_NOTIFICATION = (
        "🎉 <b>Анонс нового донорского мероприятия!</b> \n\n"
        "Открыта запись на: <b>{event_name}</b>\n"
        "🗓️ <b>Когда:</b> {event_date} в {event_time}\n"
        "📍 <b>Где:</b> {event_location}\n\n"
        "Вы можете принять участие! Записаться можно прямо сейчас через главное меню бота. "
        "Ваша помощь очень важна!"
    )


    # --- НОВЫЕ ТЕКСТЫ ---

    # --- Общие ---
    WELCOME_BACK = "✅ С возвращением, {name}!"
    MAIN_MENU_PROMPT = "Чем могу помочь?"
    USER_BLOCKED_MESSAGE = "❌ К сожалению, вы были заблокированы."
    SWITCH_TO_DONOR_VIEW = "✅ Вы переключились в режим донора. Здесь доступны все студенческие функции."
    ERROR_PROFILE_NOT_FOUND = "Ошибка: не удалось найти ваш профиль."
    ALREADY_REGISTERED = "Вы уже зарегистрированы, {name}!"
    USER_BLOCKED_ON_AUTH = "❌ Ваш аккаунт заблокирован."
    ACTION_CANCELLED = "Действие отменено."
    ADMIN_SWITCH_TO_VOLUNTEER_VIEW = "⭐ <b>Вы переключились в режим волонтера</b>"
    UNKNOWN_COMMAND = "Я не понимаю эту команду. Пожалуйста, используйте кнопки меню для навигации."
    ERROR_GENERIC_ALERT = "Произошла ошибка. Попробуйте снова."
    INFO_SECTION_NOT_FOUND = "Раздел не найден."

    # --- Регистрация FSM ---
    FACULTY_SELECTED = "Выбран факультет: {faculty}"
    BLOOD_TYPE_SELECTED = "Группа крови: {blood_type}"
    RH_FACTOR_SELECTED = "Резус-фактор: {rh_factor}"
    GENDER_SELECTED = "Пол: {gender}"
    DATE_FORMAT_ERROR = "❌ Неверный формат даты. Введите <b>ДД.ММ.ГГГГ</b>."

    # --- Профиль студента ---
    PROFILE_MENU_HEADER = "👤 <b>Мой профиль</b>\n\nВыберите, что вас интересует:"
    PROFILE_LOAD_ERROR = "Не удалось загрузить профиль."
    PROFILE_DATA_TEMPLATE = (
        "📊 <b>Ваши данные</b>\n\n"
        "👤 <b>ФИО:</b> {full_name}\n"
        "🎓 <b>Университет:</b> {university}\n"
        "🏛️ <b>Факультет:</b> {faculty}, <b>Группа:</b> {study_group}\n"
        "🩸 <b>Группа крови:</b> {blood_type} Rh{rh_factor}\n"
        "⭐ <b>Баллы:</b> {points}\n"
        "💉 <b>Всего донаций:</b> {total_donations}\n"
        "🗓️ <b>Следующая донация возможна с:</b> {next_date}"
    )
    NO_DONATION_HISTORY = "У вас еще нет записей о донациях."
    DONATION_HISTORY_HEADER = "🩸 <b>Ваша история донаций:</b>\n\n"
    DONATION_HISTORY_ITEM = "▪️ {date}: {type}, <b>+{points} баллов</b>\n"

    # --- Мероприятия (Студент) ---
    NO_ACTIVE_EVENTS = "Активных мероприятий для записи сейчас нет."
    CHOOSE_EVENT_TO_REGISTER = "Выберите мероприятие для записи:"
    ALREADY_REGISTERED_FOR_EVENT = (
        "Вы уже записаны на мероприятие «<b>{event_name}</b>».\n\n"
        "Здесь вы можете получить QR-код или отменить свою запись."
    )
    REGISTRATION_SUCCESSFUL = (
        "✅ Вы успешно записаны на: <b>{event_name}</b>\n\n"
        "📍 <b>Место проведения:</b> {event_location}\n\n"
        "Ваш QR-код для подтверждения донации доступен по кнопке ниже."
    )
    REGISTRATION_FAILED = "❌ Запись невозможна.\nПричина: {reason}"
    REGISTRATION_CANCELLED_SUCCESS = "✅ Ваша регистрация на мероприятие была отменена."
    REGISTRATION_CANCELLED_FAIL = "Не удалось отменить регистрацию. Возможно, она уже была отменена."

    # --- Магазин (Студент) ---
    MERCH_NO_ITEMS = "В магазине пока нет товаров."
    MERCH_ITEM_CAPTION = (
        "🛍️ <b>{item_name}</b>\n\n"
        "{item_description}\n\n"
        "Цена: <b>{item_price}</b> баллов\n"
        "Ваш баланс: <b>{user_points}</b> баллов"
    )
    MERCH_PURCHASE_INSUFFICIENT_FUNDS = "Недостаточно баллов. Нужно {price}, у вас {points}."
    MERCH_ITEM_NOT_FOUND = "Товар не найден."
    MERCH_PURCHASE_CONFIRMATION = (
        "Вы уверены, что хотите купить <b>'{item_name}'</b> за <b>{item_price}</b> баллов?\n\n"
        "Ваш баланс после покупки: <b>{new_balance}</b> баллов."
    )
    MERCH_PURCHASE_SUCCESS = "🎉 Поздравляем с покупкой!\n{message}\n\nМы сообщим, когда можно будет забрать заказ."
    MERCH_PURCHASE_ERROR = "⚠️ Ошибка: {message}"
    MERCH_NO_ORDERS = "У вас пока нет заказов."
    MERCH_ORDERS_HEADER = "🛍️ <b>Ваши заказы:</b>\n\n"
    MERCH_ORDER_ITEM = "▪️ <b>{item_name}</b> (от {date})\n   Статус: <b>{status}</b>\n"
    MERCH_STATUS_MAP = {'pending_pickup': 'Ожидает выдачи', 'completed': 'Выдан'}
    MERCH_UPDATE_ERROR = "Не удалось обновить. Попробуйте войти в магазин заново."

    # --- Медотводы (Студент) ---
    WAIVERS_MENU_HEADER = "⚕️ <b>Управление медицинскими отводами</b>\n"
    NO_ACTIVE_WAIVERS = "\n✅ У вас нет активных отводов. Вы можете спасать жизни! 💪"
    SYSTEM_WAIVERS_HEADER = "\n<b>Назначенные системой/администратором (нельзя отменить):</b>"
    USER_WAIVERS_HEADER = "\n<b>Установленные вами (можно отменить):</b>"
    WAIVER_ITEM_FORMAT = "▪️ До <b>{end_date}</b> по причине: «{reason}»"
    WAIVER_SET_PROMPT = (
        "Вы можете установить временный отвод от донорства (например, из-за ОРВИ или плохого самочувствия).\n\n"
        "Введите дату, до которой будет действовать отвод, в формате <b>ДД.ММ.ГГГГ</b>:"
    )
    WAIVER_DATE_IN_PAST_ERROR = "❌ Дата окончания должна быть в будущем. Попробуйте снова."
    WAIVER_REASON_PROMPT = "Отлично. Теперь кратко укажите причину (например, 'Простуда', 'Плохое самочувствие'):"
    WAIVER_SET_SUCCESS = "✅ Ваш личный медотвод успешно установлен до {end_date}."
    WAIVER_CANCELLATION_PROMPT = "Выберите, какой из ваших отводов отменить:"
    WAIVER_NOTHING_TO_CANCEL = "У вас нет отводов, которые можно отменить."
    WAIVER_CANCEL_SUCCESS = "✅ Ваш медотвод успешно отменен."
    WAIVER_CANCEL_FAIL = "❌ Не удалось отменить отвод."

    # --- Информация ---
    INFO_MENU_HEADER = "ℹ️ <b>Полезная информация</b>\n\nВыберите интересующий вас раздел:"
    
    # --- QR-код ---
    QR_GENERATING = "Генерирую ваш QR-код..."
    QR_GENERAL_CAPTION = "Этот QR-код можно использовать для быстрой идентификации. Для подтверждения донации на мероприятии используйте QR-код из меню мероприятия."
    QR_EVENT_CAPTION = "Покажите этот QR-код волонтёру после донации для начисления баллов."

    # --- Волонтер ---
    VOLUNTEER_MENU_HEADER = "⭐ <b>Меню волонтёра</b>"
    VOLUNTEER_SEND_QR_PROMPT = "Отправьте мне фотографию с QR-кодом донора."
    QR_READ_ERROR = "❌ QR-код не распознан или имеет неверный формат. Попробуйте снова."
    QR_INVALID_DATA_ERROR = "❌ QR-код содержит некорректные данные."
    QR_DB_LOOKUP_ERROR = "❌ Ошибка: Пользователь или мероприятие из QR-кода не найдены в базе."
    QR_DONOR_NOT_REGISTERED_ERROR = "❌ Ошибка: Донор <b>{donor_name}</b> не зарегистрирован на это мероприятие."
    QR_WRONG_DAY_ERROR = "❌ Ошибка: Этот QR-код для мероприятия, которое проходит не сегодня."
    VOLUNTEER_CONFIRMATION_PROMPT = (
        "🔍 <b>Подтверждение донации</b>\n\n"
        "Вы собираетесь подтвердить донацию для:\n"
        "👤 <b>Донор:</b> {donor_name}\n"
        "🗓️ <b>Мероприятие:</b> {event_name}\n\n"
        "Все верно?"
    )
    VOLUNTEER_CONFIRMATION_ERROR = "❌ Произошла ошибка. Пожалуйста, отсканируйте QR-код заново."
    DONATION_CONFIRMING = "⏳ Подтверждаю донацию..."
    DONATION_CONFIRM_ERROR_NO_REG = "❌ Ошибка: не удалось найти донора или его регистрацию. Возможно, она была отменена."
    DONATION_CONFIRM_SUCCESS = (
        "✅ Донация для <b>{donor_name}</b> на мероприятии «<b>{event_name}</b>» подтверждена.\n\n"
        "Начислено <b>{points}</b> баллов.\n\nГотовы сканировать следующий QR-код."
    )
    DONATION_CONFIRM_CRITICAL_ERROR = "Произошла критическая ошибка при подтверждении донации: {error}"
    VOLUNTEER_INVALID_INPUT_QR = "Пожалуйста, отправьте именно фотографию с QR-кодом."

    # --- Админ: Общее ---
    ADMIN_PANEL_HEADER = "⚙️ Панель администратора"

    # --- Админ: Мероприятия ---
    ADMIN_EVENTS_HEADER = "🗓️ Управление мероприятиями"
    EVENT_CREATE_STEP_1_NAME = "Шаг 1/9: Введите название мероприятия:"
    EVENT_CREATE_STEP_2_DATE = "Шаг 2/9: Введите дату и время мероприятия в формате <b>ДД.ММ.ГГГГ ЧЧ:ММ</b> (например, 25.12.2024 10:30):"
    EVENT_CREATE_STEP_3_LOCATION_TEXT = "Шаг 3/9: Введите адрес мероприятия текстом (например, 'г. Москва, ул. Каширское шоссе, д. 31'):"
    EVENT_CREATE_STEP_4_LOCATION_POINT = "Шаг 4/9: Отлично. Теперь отправьте геоточку для этого адреса, чтобы доноры могли легко построить маршрут."
    EVENT_CREATE_STEP_5_TYPE = "Шаг 5/9: Выберите тип донации:"
    EVENT_CREATE_STEP_6_POINTS = "Выбран тип: {donation_type}\n\nШаг 6/9: Введите количество баллов за донацию:"
    EVENT_CREATE_STEP_7_BONUS = "Шаг 7/9: Введите бонусные баллы за редкую кровь (можно 0):"
    EVENT_CREATE_STEP_7_RARE_TYPES = "Шаг 8/9: Отметьте группы крови, которые будут считаться редкими для этого мероприятия:"
    EVENT_CREATE_STEP_8_LIMIT = "Шаг 9/9: Введите лимит участников:"
    EVENT_LIMIT_NAN_ERROR = "❌ Лимит должен быть числом."
    EVENT_POINTS_NAN_ERROR = "❌ Введите целое число."
    DATE_FORMAT_ERROR = "❌ Неверный формат. Введите дату и время в формате <b>ДД.ММ.ГГГГ ЧЧ:ММ</b>."
    

    EVENT_CREATE_CONFIRMATION = (
        "✅ Все данные собраны. Пожалуйста, проверьте:\n\n"
        "▪️ Название: {name}\n"
        "▪️ Дата и время: {datetime}\n"
        "▪️ Адрес: {location}\n"
        "▪️ Точка на карте: {location_set}\n"
        "▪️ Тип: {type}\n"
        "▪️ Баллы: {points} (+{bonus_points})\n"
        "▪️ Редкие группы: {rare_types}\n"
        "▪️ Лимит: {limit}\n\n"
        "Создать мероприятие и запустить рассылку?"
    )

    
    EVENT_CREATING_IN_PROGRESS = "Принято. Создаю мероприятие..."
    EVENT_CREATE_SUCCESS = "✅ Мероприятие успешно создано!"
    MAILING_STARTED_NOTIFICATION = "⏳ Начинаю рассылку. Это может занять некоторое время..."
    MAILING_FINISHED_NOTIFICATION = "✅ Рассылка завершена.\n\nОтправлено: {success}\nОшибок: {fail}"
    MAILING_ERROR = "❌ Произошла ошибка во время рассылки."
    ADMIN_NO_ACTIVE_EVENTS = "Активных мероприятий нет."
    ADMIN_CHOOSE_EVENT_TO_MANAGE = "Выберите мероприятие для управления:\n(✅ - регистрация открыта, 🔒 - закрыта)"
    EVENT_NOT_FOUND = "Мероприятие не найдено."
    EVENT_CARD_TEMPLATE = (
        "🗓️ {name}\n\n"
        "▪️ {date_header} {datetime}\n" 
        "▪️ {location_header} {location}\n"
        "▪️ {type_header} {donation_type}\n"
        "▪️ {points_header} {points_per_donation} (+{rare_blood_bonus_points} за редкую кровь)\n"
        "▪️ {limit_header} {reg_count}/{participant_limit}\n"
        "▪️ {status_header} {is_active}\n"
        "▪️ {reg_status_header} {reg_is_open}"
    )
    EVENT_TOGGLE_REG_OPEN = "Регистрация на мероприятие теперь открыта."
    EVENT_TOGGLE_REG_CLOSED = "Регистрация на мероприятие теперь закрыта."
    EVENT_EDIT_PROMPT = "Вы редактируете: <b>{event_name}</b>\n\nКакое поле хотите изменить?"
    EVENT_EDIT_FIELD_PROMPTS = {
        "name": "Введите новое название:",
        "event_date": "Введите новую дату (ДД.ММ.ГГГГ):",
        "location": "Введите новое место:",
        "points_per_donation": "Введите новое кол-во баллов:",
        "participant_limit": "Введите новый лимит:"
    }
    EVENT_EDIT_INVALID_FORMAT = "❌ Неверный формат данных. Попробуйте снова."
    EVENT_EDIT_SUCCESS = "✅ Поле успешно обновлено!"
    EVENT_NO_PARTICIPANTS = "На '{event_name}' пока никто не записался."
    EVENT_PARTICIPANTS_CAPTION = "Участники мероприятия '{event_name}'"
    EVENT_CANCEL_CONFIRMATION = "🚨 <b>Подтверждение отмены</b>\n\nВы уверены, что хотите отменить «<b>{event_name}</b>»?\n\nУведомление будет отправлено <b>{reg_count}</b> участникам."
    EVENT_CANCELLING_IN_PROGRESS = "⏳ Начинаю процесс отмены..."
    EVENT_CANCEL_NOTIFICATION_TEXT = "❗️ <b>Внимание, мероприятие отменено!</b>\n\nК сожалению, «<b>{event_name}</b>», запланированное на {datetime}, было отменено."
    EVENT_CANCEL_SUCCESS_REPORT = "✅ <b>Мероприятие «{event_name}» отменено.</b>\n\n<b>Результаты:</b>\n- Успешно отправлено: {success}\n- Ошибок: {fail}"
    # --- Админ: Рассылки ---
    MAILING_STEP_1_TEXT_PROMPT = (
        "Вы начали создание рассылки.\n\n"
        "<b>Шаг 1/3:</b> Введите текст сообщения. Он будет подписью, если вы добавите фото/видео. "
        "Можно использовать HTML-теги: <b>жирный</b>, <i>курсив</i>, <code>код</code>, <a href='...'>ссылка</a>.\n\n"
        "Чтобы отменить, нажмите /cancel."
    )
    MAILING_STEP_2_MEDIA_PROMPT = (
        "Текст получен.\n\n"
        "<b>Шаг 2/3:</b> Теперь отправьте фото или видео, которое нужно прикрепить к рассылке. "
        "Если хотите отправить только текст, нажмите 'Пропустить'."
    )
    MAILING_PHOTO_RECEIVED = "Фото получено.\n\n<b>Шаг 3/3:</b> Выберите аудиторию для рассылки:"
    MAILING_VIDEO_RECEIVED = "Видео получено.\n\n<b>Шаг 3/3:</b> Выберите аудиторию для рассылки:"
    MAILING_STEP_3_AUDIENCE_PROMPT = "<b>Шаг 3/3:</b> Выберите аудиторию для рассылки:"
    MAILING_AUDIENCE_MAP = {
        "all": "Всем пользователям",
        "can_donate": "Донорам, которые могут сдавать",
        "volunteers": "Волонтерам",
        "admins": "Администраторам"
    }
    MAILING_PREVIEW_HEADER = (
    "<b>🔍 Проверьте рассылку перед запуском</b>\n\n"
    "<b>👤 Аудитория:</b> {audience}\n"
    "<b>👥 Получателей:</b> {count}\n"
    )
    MAILING_PREVIEW_WITH_PHOTO = "🖼️ <b>Прикреплено фото</b>\n"
    MAILING_PREVIEW_WITH_VIDEO = "📹 <b>Прикреплено видео</b>\n"
    MAILING_PREVIEW_TEXT_HEADER = "\n<b>✉️ Текст/подпись:</b>\n------------------------------------\n{text}\n------------------------------------"
    MAILING_EDIT_TEXT_PROMPT = "Введите новый текст сообщения для рассылки:"
    MAILING_CONFIRMED_AND_RUNNING = "✅ Рассылка запущена в фоновом режиме. Вы можете продолжать пользоваться ботом."
    
    # --- Админ: Мерч ---
    ADMIN_MERCH_HEADER = "🛍️ <b>Управление магазином</b>"
    MERCH_CREATE_STEP_1_PHOTO = "Отправьте фотографию для нового товара."
    MERCH_PHOTO_RECEIVED = "Фото получено. Введите название товара:"
    MERCH_NAME_RECEIVED = "Название сохранено. Введите описание товара:"
    MERCH_DESC_RECEIVED = "Описание сохранено. Введите цену в баллах:"
    MERCH_PRICE_NAN_ERROR = "❌ Цена должна быть целым числом."
    MERCH_CREATE_PHOTO_ID_ERROR = "❌ Произошла ошибка: ID фото не был сохранен. Начните заново."
    MERCH_CREATE_SUCCESS = "✅ Товар успешно добавлен!"
    ADMIN_NO_MERCH_ITEMS = "В магазине пока нет товаров."
    ADMIN_CHOOSE_MERCH_TO_MANAGE = "Выберите товар для управления:"
    MERCH_CARD_CAPTION = (
        "🛍️ <b>Товар: {name}</b>\n\n"
        "▪️ <b>Описание:</b> {description}\n"
        "▪️ <b>Цена:</b> {price} баллов\n"
        "▪️ <b>Статус:</b> {status}"
    )
    MERCH_EDIT_PROMPT = "Вы редактируете: <b>{name}</b>\n\nКакое поле хотите изменить?"
    MERCH_EDIT_FIELD_PROMPTS = {
        "name": "Введите новое название:",
        "description": "Введите новое описание:",
        "price": "Введите новую цену в баллах:"
    }
    MERCH_EDIT_NEW_VALUE_PROMPT = "Введите новое значение:"
    MERCH_EDIT_SUCCESS = "✅ Поле успешно обновлено!"
    MERCH_TOGGLE_AVAILABILITY = "Статус изменен на: {status}."
    MERCH_DELETE_CONFIRMATION = "🗑️ <b>Подтверждение удаления</b>\n\nВы уверены, что хотите <b>безвозвратно</b> удалить «<b>{name}</b>»?"
    MERCH_DELETE_SUCCESS = "✅ Товар «<b>{name}</b>» был удален."
    MERCH_ITEM_ALREADY_DELETED = "Товар уже удален."
    ADMIN_NO_PENDING_ORDERS = "Новых заказов нет."
    ADMIN_PENDING_ORDERS_HEADER = "📦 <b>Новые заказы на выдачу:</b>\n\n"
    ADMIN_ORDER_ITEM_TEXT = (
        "🔹 <b>Заказ №{order_id}</b> от {date}\n"
        "   Товар: «{item_name}»\n"
        "   Заказал: {user_link} (@{username})\n"
        "   Телефон: {phone}"
    )
    ADMIN_ORDER_ITEM_TEXT_NO_USERNAME = (
        "🔹 <b>Заказ №{order_id}</b> от {date}\n"
        "   Товар: «{item_name}»\n"
        "   Заказал: {user_link}\n"
        "   Телефон: {phone}"
    )
    ADMIN_COMPLETE_ORDER_ADMIN_ID_ERROR = "Ошибка: не удалось идентифицировать администратора."
    ADMIN_ORDER_NOT_FOUND_OR_PROCESSED = "Заказ не найден или уже обработан."
    ADMIN_ORDER_COMPLETED_SUCCESS = "✅ Заказ №{order_id} помечен как выданный."
    USER_ORDER_COMPLETED_NOTIFICATION = "🎉 Ваш заказ «{item_name}» был выдан. Приятного пользования!"

    # --- Админ: Система ---
    EXPORT_STARTED = "⏳ Начинаю сбор данных и создание архива... Это может занять некоторое время."
    EXPORT_SUCCESSFUL = "✅ Полный бэкап базы данных готов."
    EXPORT_FAILED = "❌ Произошла ошибка при создании бэкапа. Подробности в логах."
    
    # --- Админ: Пользователи ---
    ADMIN_USERS_HEADER = "👥 <b>Управление пользователями</b>"
    ADMIN_NO_USERS_IN_DB = "В базе данных пока нет пользователей."
    USERS_LIST_HEADER = "📜 <b>Список пользователей (Страница {page}/{total_pages})</b>\n\n"
    USER_SEARCH_PROMPT = "🔍 Введите запрос для поиска (ФИО, username, ID, телефон):"
    USER_SEARCH_NO_RESULTS = "🤷‍♂️ По вашему запросу никого не найдено."
    USER_SEARCH_RESULTS_HEADER = "🔍 <b>Результаты поиска по запросу «{query}»:</b>\n\n"
    USER_CARD_HEADER = "👤 Профиль пользователя: {full_name}"
    USER_CARD_TEMPLATE = (
        "  <b>ФИО:</b> {full_name}\n"
        "  <b>ID:</b> <code>{telegram_id}</code>\n"
        "  <b>Username:</b> @{username}\n"
        "  <b>Телефон:</b> <code>{phone_number}</code>\n"
        "  <b>Роль:</b> <code>{role}</code>\n"
        "  <b>Баллы:</b> <b>{points}</b>\n"
        "  <b>Статус:</b> <b>{block_status}</b>"
    )
    USER_NOT_FOUND = "Пользователь не найден."
    CHANGE_POINTS_PROMPT = "Введите сумму баллов для начисления (например, 50) или списания (-50):"
    CHANGE_POINTS_REASON_PROMPT = "Введите причину начисления/списания:"
    CHANGE_POINTS_SUCCESS = "✅ Баланс пользователя {name} изменен. Новый баланс: {balance}"
    USER_POINTS_CHANGED_NOTIFICATION = "⚙️ Администратор изменил ваш баланс на {points} баллов.\n<b>Причина:</b> {reason}\n<b>Ваш новый баланс:</b> {balance}"
    USER_PROMOTED_VOLUNTEER = "✅ Пользователь {name} назначен волонтером."
    USER_PROMOTED_VOLUNTEER_NOTIFY = "⭐ Поздравляем! Администратор назначил вас волонтером. Вам доступно меню волонтера."
    USER_DEMOTED_VOLUNTEER = "✅ Пользователь {name} снят с должности волонтера."
    USER_DEMOTED_VOLUNTEER_NOTIFY = "⚙️ Ваша роль изменена на 'студент'. Меню волонтера больше недоступно."
    USER_PROMOTED_ADMIN = "✅ {name} назначен администратором."
    USER_PROMOTED_ADMIN_NOTIFY = "Поздравляем! Вас назначили администратором бота."
    USER_DEMOTED_ADMIN = "✅ {name} разжалован до студента."
    USER_DEMOTED_ADMIN_NOTIFY = "Ваша роль изменена на 'студент'."
    BLOCK_USER_REASON_PROMPT = "Введите причину блокировки:"
    ADMIN_ID_ERROR = "Критическая ошибка: не удалось идентифицировать вас."
    BLOCK_TARGET_USER_NOT_FOUND = "Ошибка: целевой пользователь не найден."
    USER_BLOCKED_SUCCESS = "✅ Пользователь {name} заблокирован. Причина: {reason}"
    USER_BLOCKED_NOTIFY = "Ваш аккаунт был заблокирован.\nПричина: {reason}"
    USER_UNBLOCKED_SUCCESS = "✅ Пользователь {name} успешно разблокирован."
    USER_UNBLOCKED_NOTIFY = "🎉 Ваш аккаунт был разблокирован. Теперь вы снова можете пользоваться ботом."
    MANAGE_USER_REGS_HEADER = "🎟️ Управление регистрациями для: <b>{name}</b>\n\nВыберите действие:"
    MANUAL_REG_CHOOSE_EVENT = "Выберите мероприятие, на которое нужно записать пользователя:"
    MANUAL_REG_NO_EVENTS = "Нет предстоящих мероприятий для записи."
    MANUAL_REG_SUCCESS_NOTIFY = "⚙️ Администратор записал вас на мероприятие «<b>{event_name}</b>» на {datetime}."
    NOTIFY_USER_FAILED = "⚠️ Не удалось уведомить пользователя {name}."
    MANUAL_CANCEL_CHOOSE_REG = "Выберите регистрацию, которую нужно отменить:"
    MANUAL_CANCEL_NO_REGS = "У этого пользователя нет активных регистраций на будущие мероприятия."
    MANUAL_CANCEL_SUCCESS = "Регистрация пользователя {name} на {event_name} отменена."
    MANUAL_CANCEL_SUCCESS_NOTIFY = "⚙️ Администратор отменил вашу запись на мероприятие «<b>{event_name}</b>»."
    MANUAL_CANCEL_FAIL = "Не удалось отменить регистрацию (возможно, уже отменена)."
    MANAGE_WAIVERS_HEADER = "⚕️ Управление медотводами пользователя <b>{name}</b>.\n\n"
    MANAGE_WAIVERS_NO_WAIVERS = "Активных медотводов нет. Вы можете установить новый."
    MANAGE_WAIVERS_WITH_WAIVERS = "Нажмите на медотвод, чтобы удалить, или установите новый:"
    MANUAL_WAIVER_DATE_PROMPT = "Введите дату окончания медотвода в формате ДД.ММ.ГГГГ:"
    MANUAL_WAIVER_REASON_PROMPT = "Введите причину медотвода:"
    MANUAL_WAIVER_SUCCESS = "✅ Медотвод для {name} установлен до {date}."
    MANUAL_WAIVER_NOTIFY = "⚕️ Администратор установил вам медотвод до {date}.\n<b>Причина:</b> {reason}"
    ADMIN_DELETE_WAIVER_DATA_ERROR = "Ошибка в данных. Попробуйте снова."
    ADMIN_DELETE_WAIVER_SUCCESS = "✅ Медотвод успешно удален."
    ADMIN_DELETE_WAIVER_FAIL = "❌ Не удалось удалить медотвот."
    ADMIN_DELETE_WAIVER_NOTIFY = "⚙️ Администратор отменил один из ваших медицинских отводов."
    WAIVER_EXPIRED_NOTIFICATION = "🎉 Отличные новости! Срок вашего медицинского отвода истек. Вы снова можете спасать жизни, участвуя в донациях! 💪"
    REMINDER_WEEK = (
        "👋 <b>Напоминание о донации через неделю!</b> \n\n"
        "Вы записаны на мероприятие «<b>{event_name}</b>», которое состоится через неделю - <b>{event_datetime}</b>.\n\n"
        "📍 <b>Место:</b> {event_location}\n\n"
        "Пожалуйста, начните готовиться к донации заранее и следите за своим самочувствием. Спасибо!"
    )
    REMINDER_2_DAYS = (
        "👋 <b>Напоминание о донации!</b> \n\n"
        "Вы записаны на мероприятие «<b>{event_name}</b>», которое состоится послезавтра, <b>{event_datetime}</b>.\n\n"
        "📍 <b>Место:</b> {event_location}\n\n"
        "Пожалуйста, не забудьте паспорт и хорошо выспитесь. Спасибо, что помогаете!"
    )
    REMINDER_2_HOURS = (
        "❗️<b>Донация уже скоро!</b> \n\n"
        "Напоминаем, что вы записаны на мероприятие «<b>{event_name}</b>», которое начнется уже через 2 часа, в <b>{event_datetime}</b>.\n\n"
        "Ждем вас по адресу: {event_location}"
    )
    POST_DONATION_FEEDBACK = "Привет! Как ты себя чувствуешь?\n\nОцени, пожалуйста, организацию мероприятия 1/5"
    
    
    FEEDBACK_START = "👋 Привет! Спасибо за твою донацию вчера. Мы были бы очень признательны, если бы ты ответил(а) на несколько вопросов. Это поможет нам стать лучше!\n\nДля начала, как ты себя чувствуешь после донации? Оцени по шкале от 1 (очень плохо) до 5 (отлично)."
    FEEDBACK_WELL_BEING_BAD = "Нам жаль это слышать. Пожалуйста, напиши, что именно не так? (например, 'кружится голова', 'слабость'). Если тебе нужна помощь, обязательно свяжись с нами!"
    FEEDBACK_GET_ORGANIZATION_SCORE = "Понятно, спасибо! Теперь оцени, пожалуйста, организацию самого мероприятия по шкале от 1 (очень плохо) до 10 (отлично)."
    FEEDBACK_GET_WHAT_LIKED = "Отлично! Расскажи, пожалуйста, что тебе понравилось больше всего?"
    FEEDBACK_GET_WHAT_DISLIKED = "Спасибо! А что можно было бы улучшить? Что не понравилось?"
    FEEDBACK_GET_OTHER_SUGGESTIONS = "Принято. И последний вопрос: есть ли у тебя какие-либо другие идеи или предложения?"
    FEEDBACK_FINISH = "🎉 Опрос завершён! Огромное спасибо за твою обратную связь. Она очень важна для нас!"

    FEEDBACK_ADMIN_HEADER = "📊 <b>Отзывы по мероприятию «{event_name}»</b>\n\n"
    FEEDBACK_ADMIN_NO_FEEDBACK = "По этому мероприятию пока нет отзывов."
    FEEDBACK_ADMIN_ITEM = (
        "--- Отзыв от {user_name} ---\n"
        "<b>Самочувствие:</b> {wb_score}/5\n"
        "<i>Комментарий:</i> {wb_comment}\n"
        "<b>Организация:</b> {org_score}/10\n"
        "<b>👍 Понравилось:</b> {liked}\n"
        "<b>👎 Не понравилось:</b> {disliked}\n"
        "<b>💬 Предложения:</b> {suggestions}\n\n"
    )